const Canvas = ({family,newText,textSize,wallpaper}) => {
    
  return (
    <div className={"canva h-full w-4/5  bg-yellow-500 bg-cover object-scale-down px-10 py-10 overflow-scroll "+family+textSize+wallpaper}>
     
      Additionally, the way magical power is drawn has also been altered.
      Previously, players would draw their magical power from an external
      source, such as the sky. However, the current version has players drawing
      their magical power from within themselves. This shift allows for greater
      creativity and versatility in how players interact with and utilize their
      magical abilities.
      {newText}
    </div>
  );
};

export default Canvas;
